# Cara Update Portofolio di GitHub Pages Kamu

Kamu sudah punya repo `aquillaluthfie.github.io` yang aktif. Ini cara paling gampang untuk menggantinya dengan versi baru ini (tanpa perlu install apa-apa di laptop):

## Langkah-langkah (lewat browser saja)

1. Buka repo kamu: **https://github.com/aquillaluthfie/aquillaluthfie.github.io**
2. Klik file **`index.html`** yang lama → klik ikon pensil (Edit) di pojok kanan atas.
3. Hapus semua isinya, lalu copy-paste seluruh isi file `index.html` yang saya buatkan ini ke sana.
4. Scroll ke bawah, klik **"Commit changes"**.
5. Balik ke halaman utama repo → klik **"Add file" → "Upload files"**.
6. Buat folder bernama `certs` dengan cara: saat upload, drag & drop ke-13 file gambar (`c01_...jpg` sampai `c13_...jpg`) sekaligus, lalu ketik `certs/` di depan nama file jika GitHub tidak otomatis membuat foldernya — atau paling mudah: buka folder `certs` di file yang saya kirim, lalu upload semua isinya ke path `certs/` di repo (ketik `certs` di kolom "Add files via upload" akan otomatis membuat folder saat kamu drag file ke dalamnya).
7. Commit changes lagi.
8. Tunggu 1-2 menit, buka **https://aquillaluthfie.github.io** — portofolio barunya sudah tayang.

## Kalau mau pakai command line (opsional, lebih cepat)

```bash
git clone https://github.com/aquillaluthfie/aquillaluthfie.github.io.git
cd aquillaluthfie.github.io
# copy index.html dan folder certs/ dari hasil unduhan ke folder ini (timpa yang lama)
git add .
git commit -m "Update portofolio dengan sertifikat"
git push
```

## Catatan
- Total ukuran 13 gambar sertifikat ± 2.4 MB — aman untuk GitHub Pages (limit repo 1GB, limit soft 100MB per file).
- Klik gambar sertifikat di halaman akan membuka versi besarnya (lightbox) — sudah jalan otomatis, tidak perlu setting tambahan.
- Foto galeri kerja (BWE, panel listrik, dll) masih placeholder "Foto menyusul" — kirim ke saya kalau mau saya pasang juga.
